#!/usr/bin/env python3
"""Reference-ratio normalization trial, preserving inherited glyph contours.
JetBrains Mono is measured, never embedded or copied. Original contours are
modified by piecewise-coordinate editing, not uniform glyph scaling.
"""
from pathlib import Path
import hashlib,json,math,zipfile,shutil
from fontTools.ttLib import TTFont
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.recordingPen import DecomposingRecordingPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.pointPen import SegmentToPointPen
from fontTools.ufoLib import UFOWriter
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;ROOT=R.parent
SRC=ROOT/'DaikonicTransitMono-v0.6/fonts/DaikonicTransitMono-Regular.ttf'
REF=Path('/usr/share/texlive/texmf-dist/fonts/opentype/SIL/jetbrainsmono-otf/JetBrainsMono-Regular.otf')
for d in ('fonts','source','proofs','svg','qa'): (R/d).mkdir(exist_ok=True)
d=TTFont(SRC);j=TTFont(REF);orig=TTFont(SRC)
gset=orig.getGlyphSet(); jset=j.getGlyphSet();dc=orig.getBestCmap();jc=j.getBestCmap();glyphs=d['glyf'];CELL=650

def get_bounds(font, name):
 p=BoundsPen(font.getGlyphSet());font.getGlyphSet()[name].draw(p)
 return p.bounds

def ctype(char):
 if char.islower():return 'lower'
 if char.isupper():return 'upper'
 if char.isdigit():return 'digit'
 return 'punct'

# The left/right breadth of a monospaced letter is a proportion of its own
# advance; the two typefaces have 600 and 650 unit cells respectively.
# Deliberately narrow forms are distinct constructions; use target as a guide,
# not a forced substitution of a different style of i/l/1.
SKIP=set('iIl1')
# These are preserved due to unique Johnston forms / optical distinctiveness.
# As requested, narrow t, f, r and operators are *not* excluded.
SKIP|=set('!|')
# Avoid shifting unreviewed punctuation contours, accents etc.
CHARS='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-=<>*/?!:;{}[]()|&$%^_~'

# Width targets use genuine JetBrains ink width ratios. Each target is
# capped to maintain at least 47 units breathing room from cell edges.
metric=[]; targets={}; groups={}
for ch in CHARS:
 if ord(ch) not in dc or ord(ch) not in jc:continue
 a=dc[ord(ch)];b=jc[ord(ch)]
 old=get_bounds(orig,a);jb=get_bounds(j,b)
 if old is None or jb is None:continue
 ow=old[2]-old[0];jw=jb[2]-jb[0]
 desired=min(556,round(jw/j['hmtx'][b][0]*CELL))
 if ch in SKIP:desired=round(ow)
 # Constraint: avoid destroying the historic stroke constructions when the
 # requested target is geometrically incompatible with their inner stroke mass.
 # Still record unmatched target for review.
 if ch not in SKIP:
  desired=max(ow-135,min(desired,ow+95))
 row={'character':ch,'glyph':a,'category':ctype(ch),'jb_ink':round(jw),'jb_cell':j['hmtx'][b][0], 'jb_ratio':round(jw/j['hmtx'][b][0],4),'v06_ink':round(ow),'nominal_target_ink':round(jw/j['hmtx'][b][0]*CELL),'applied_target_ink':desired,'width_delta':round(desired-ow),'exception':ch in SKIP}
 metric.append(row)
 if abs(desired-ow)>=3 and ch not in SKIP: targets[a]=(old,desired,ch)

# For component contours, use parent codepoint and NFD decomposition to apply
# the same base spacing to accented variants. Pure accents remain untouched.
import unicodedata
rev={}
for cp,n in dc.items():rev.setdefault(n,[]).append(cp)
for gname in orig.getGlyphOrder():
 if gname in targets:continue
 for cp in rev.get(gname,[]):
  nfd=unicodedata.normalize('NFD',chr(cp))
  if len(nfd)>1 and ord(nfd[0]) in dc:
   base=dc[ord(nfd[0])]
   if base in targets:
    old,target,ch=targets[base]
    targets[gname]=(old,target,ch)
   break

# Piecewise contour positioning: preserve outer 90-unit stroke bands rather
# than scaling their thickness. This is a conservative draft; middle strokes
# should be reviewed in outline editor before production approval.
def newx(x,left,right,target,band=90):
 w=right-left;band=min(band,w*.22)
 newleft=(CELL-target)/2
 if x<=left+band:return newleft+(x-left)
 if x>=right-band:return newleft+target-band+(x-(right-band))
 return newleft+band+(x-left-band)*(target-2*band)/(w-2*band)

for name,(b,target,ch) in targets.items():
 rec=DecomposingRecordingPen(gset);gset[name].draw(rec)
 p=TTGlyphPen(None); low,top=b[0],b[2]
 # Accents require keeping distinct marks in place; only transform contours
 # whose vertical extent overlaps the base letter body.
 parts=[];cur=[]
 for command,args in rec.value:
  if command=='moveTo' and cur:parts.append(cur);cur=[]
  cur.append((command,args))
  if command in ('closePath','endPath'):parts.append(cur);cur=[]
 if cur:parts.append(cur)
 for contour in parts:
  yy=[v[1] for op,args in contour if op in ('moveTo','lineTo','qCurveTo','curveTo') for v in args if v is not None]
  alter=(name==dc.get(ord(ch)) or (yy and min(yy)<b[3]-7 and max(yy)>b[1]+7))
  for command,args in contour:
   if command in ('moveTo','lineTo','qCurveTo','curveTo'):
    pts=[]
    for v in args:
     if v is None:pts.append(None)
     else:
      xx=newx(v[0],low,top,target) if alter else v[0]
      pts.append((int(round(xx)),int(round(v[1]))))
    getattr(p,command)(*pts)
   else:getattr(p,command)()
 new=p.glyph();new.recalcBounds(glyphs);glyphs[name]=new

for name in d.getGlyphOrder():
 g=glyphs[name]
 if g.numberOfContours>0:
  g.recalcBounds(glyphs)
  d['hmtx'].metrics[name]=(d['hmtx'][name][0],g.xMin)
for name in d.getGlyphOrder():
 if name.startswith('lig.'):
  g=glyphs[name]
  if g.numberOfContours>0:g.recalcBounds(glyphs)
# Keep all original OpenType features and ligatures by editing only glyf/hmtx.
d['head'].fontRevision=1.007
for platform,encoding,lang in ((3,1,0x409),(1,0,0)):
 d['name'].setName('Version 1.007',5,platform,encoding,lang)
 d['name'].setName('1.007;Daikonic;DaikonicTransitMono-Regular',3,platform,encoding,lang)
FONT=R/'fonts/DaikonicTransitMono-Regular.ttf';d.save(FONT)
web=TTFont(FONT);web.flavor='woff2';web.save(R/'fonts/DaikonicTransitMono-Regular.woff2')

# Export editable UFO source from exact new font; no copied reference outlines.
f=TTFont(FONT);ds=f.getGlyphSet()
baseu=ROOT/'DaikonicTransitMono-v0.6/source/DaikonicTransitMono-Regular.ufo'
feat=(baseu/'features.fea').read_text()
ufop=R/'source/DaikonicTransitMono-Regular.ufo';writer=UFOWriter(str(ufop),formatVersion=3)
class Info:
 familyName='Daikonic Transit Mono';styleName='Regular';unitsPerEm=1000;ascender=950;descender=-250;xHeight=475;capHeight=700;openTypeOS2WeightClass=400;postscriptFontName='DaikonicTransitMono-Regular'
writer.writeInfo(Info());writer.writeFeatures(feat);us=writer.getGlyphSet()
for n in f.getGlyphOrder():
 class Glyph:
  width=f['hmtx'][n][0];unicodes=rev.get(n,[])
 us.writeGlyph(n,Glyph(),lambda pen,n=n: ds[n].draw(SegmentToPointPen(pen)))
us.writeContents();writer.writeLayerContents()
for row in metric:
 n=row['glyph'];pen=SVGPathPen(ds);ds[n].draw(pen)
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 650 1100" width="650" height="1100"><g fill="#182c42" transform="translate(0 820) scale(1 -1)"><path d="{pen.getCommands()}"/></g></svg>'
 (R/'svg'/f'{n}.svg').write_text(svg)

# Verify exact codepoint widths, shaping feature retained, and target fidelity.
verify=[]
for row in metric:
 name=row['glyph'];b=get_bounds(f,name);actual=b[2]-b[0]
 row['v07_ink']=round(actual);row['error_to_target']=round(actual-row['applied_target_ink']);verify.append(row)
assert all(f['hmtx'][row['glyph']][0]==650 for row in metric)
assert all(f['hmtx'][n][0]==len(seq)*650 for n,seq in {'lig.notEqual':'!=','lig.arrow':'->','lig.arrowdouble':'->>','lig.strictEqual':'===','lig.scope':'::'}.items())
assert 'calt' in f['GSUB'].table.FeatureList.FeatureRecord[0].FeatureTag or any(x.FeatureTag=='calt' for x in f['GSUB'].table.FeatureList.FeatureRecord)
(R/'qa'/'glyph-width-benchmarks.json').write_text(json.dumps({'reference':'JetBrains Mono Regular (system OTF)', 'reference_sha256':hashlib.sha256(REF.read_bytes()).hexdigest(),'reference_em':1000,'reference_cell':600,'source':'Daikonic Transit Mono v0.6','source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'target_cell':650,'method':'Ink-width ratio benchmark; protected outer stroke bands; preserved selected Johnston forms','glyphs':verify},indent=2))

# Render matching side-by-side font comparisons and bounds grids.
navy='#152e43';muted='#526679';orange='#df712d'
sys='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
for title,rows,file,canv in [
 ('Reference-ratio study | Daikonic Transit Mono', [('JetBrains Mono · reference',str(REF)),('Daikonic · v0.6',str(SRC)),('Daikonic · v0.7',str(FONT))],'DaikonicTransitMono-v07-Comparison.png',(1900,1290)),
 ('Coding glyph proportions', [('Daikonic · v0.6',str(SRC)),('Daikonic · v0.7',str(FONT))],'DaikonicTransitMono-v07-Code.png',(1900,1120))]:
 im=Image.new('RGB',canv,'#fcfbf9');dr=ImageDraw.Draw(im)
 dr.text((65,42),title,font=ImageFont.truetype(sys,39),fill=navy)
 dr.text((66,98),'Widths measured against JetBrains Mono Regular; all Daikonic glyph advances remain 650.',font=ImageFont.truetype(sys,21),fill=muted)
 for i,(label,path) in enumerate(rows):
  y=172+i*(342 if len(rows)==3 else 440)
  dr.text((65,y),label,font=ImageFont.truetype(sys,27),fill=orange if i==len(rows)-1 else muted)
  for k,line in enumerate(('ofrt xoxo lorem ipsum', 'HMBP OWNX 0123456789','if (foo != bar) return foo ->> next;') if len(rows)==3 else ('nnnonono rrttff xoxo','ABCDEFGHIJKLM NOPQRSTUVWXYZ','return m.w != null && count === 3;')):
   font=ImageFont.truetype(path,59 if len(rows)==3 else 67)
   dr.text((85,y+53+k*(85 if len(rows)==3 else 107)),line,font=font,fill=navy)
  dr.line((65,y+(314 if len(rows)==3 else 401),1830,y+(314 if len(rows)==3 else 401)),fill='#dde4e9',width=2)
 im.save(R/'proofs'/file)

# Table audit for user inspection
im=Image.new('RGB',(1850,1150),'#fcfbf9');dr=ImageDraw.Draw(im);dr.text((44,28),'Normalized ink widths · target vs current',font=ImageFont.truetype(sys,34),fill=navy)
ft=ImageFont.truetype(sys,17);ff=ImageFont.truetype(sys,22)
for i,row in enumerate(verify[:78]):
 col=i//26;index=i%26;x=40+col*600;y=94+index*39
 dr.text((x,y),row['character'],font=ff,fill=navy)
 target=row['nominal_target_ink'];v06=row['v06_ink'];v07=row['v07_ink']
 dr.text((x+44,y+4),f'{v06:>3} → {v07:>3}  /  JB {target:>3}',font=ft,fill=muted)
im.save(R/'proofs/DaikonicTransitMono-v07-Width-Audit.png')
shutil.copy(ROOT/'DaikonicTransitMono-v0.6/OFL.txt',R/'OFL.txt')
(R/'README.md').write_text('''# Daikonic Transit Mono v0.7 — benchmark-normalized trial\n\nThis is a width-proportion study against **JetBrains Mono Regular**, with the actual v0.6 Daikonic outlines as input. The JetBrains font is only a measuring reference, never embedded.\n\nMethod: convert each JetBrains glyph ink-width/cell ratio (600-unit cell) to the Daikonic 650-unit cell. Redraw the corresponding Daikonic outline with piecewise x-coordinate changes protecting outer stroke bands; preserve deliberate narrow `i`, distinctive hooked `l`, and coding `1`. Existing operator ligatures and features remain.\n\n**Limitations:** local stroke protection does not prove uniform weight at every internal joint. The width target is an engineering benchmark, not automatic typographic quality. Several radically different forms are deliberately exempt or constrained; inspect `qa/glyph-width-benchmarks.json` for differences between nominal and applied targets. No visual approval for editor use is claimed.\n\nExports: TTF, WOFF2, editable UFO, individual SVGs, comparison proofs, detailed per-character benchmark table. Source derives from Metropolitan Line/Railway Sans; licensing under SIL OFL 1.1.\n''')
with zipfile.ZipFile(ROOT/'DaikonicTransitMono-v0.7.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in R.rglob('*'):
  if p.is_file():z.write(p,arcname=str(p.relative_to(ROOT)))
print('BUILT',FONT,'CHARACTERS',len(metric),'ADJUSTED',len(targets),'ZIP',ROOT/'DaikonicTransitMono-v0.7.zip')
