# Daikonic Transit Mono v0.7 — benchmark-normalized trial

This is a width-proportion study against **JetBrains Mono Regular**, with the actual v0.6 Daikonic outlines as input. The JetBrains font is only a measuring reference, never embedded.

Method: convert each JetBrains glyph ink-width/cell ratio (600-unit cell) to the Daikonic 650-unit cell. Redraw the corresponding Daikonic outline with piecewise x-coordinate changes protecting outer stroke bands; preserve deliberate narrow `i`, distinctive hooked `l`, and coding `1`. Existing operator ligatures and features remain.

**Limitations:** local stroke protection does not prove uniform weight at every internal joint. The width target is an engineering benchmark, not automatic typographic quality. Several radically different forms are deliberately exempt or constrained; inspect `qa/glyph-width-benchmarks.json` for differences between nominal and applied targets. No visual approval for editor use is claimed.

Exports: TTF, WOFF2, editable UFO, individual SVGs, comparison proofs, detailed per-character benchmark table. Source derives from Metropolitan Line/Railway Sans; licensing under SIL OFL 1.1.
